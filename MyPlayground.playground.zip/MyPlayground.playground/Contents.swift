import UIKit

var greeting = "Hello, playground"

// swift basics

let name = "razan"

var age = 23

var GPA = 3.28

print("My name is \(name)","I am \(age) years old","My GPA is \(GPA)")

var numericString = "10"

print(Int(numericString))

print(Double(numericString))

print("As an Int: \(Int(numericString))", "As an double: \(Double(numericString))")

print("My age as double \(Double(age))","My GPA as int \(Int(GPA))")

var isStudent = true

print("Is a student: \(isStudent)")

if age >= 13 && age <= 19 {
    print("I am a teenager")
} else {
    print("I am not a teenager")
}

if age < 18 || age >= 65 {
    print("Eligible for discount")
} else {
    print("Not eligible for discount")
}


// functions

//create the functiom
func greet(person: String, kfhID: Int){
    print("Hello Fursa🚨!\n",person) // there are many ways to print *person* such as the one i used in the code above and one like ("like",person)
    print("My ID:",kfhID)
}

// call the functions
greet(person: name,kfhID: 83327)

// demo
func addNumbers(num1: Double,num2: Int) -> Int {
    
    return Int(num1) + num2
}

addNumbers(num1: 5, num2: 5)

func isLongerThanTen(text: String) -> Bool {
    print(text.count)
    
    if text.count > 10 {
        return true
    } else {
        return false
    }
}

isLongerThanTen(text: "Razan alshatti")


func isShorterOrEqualThanFive(text: String) -> Bool {
    print(text.count)
    
    if text.count <= 5 {
        return true
    } else {
        return false
    }
}

isShorterOrEqualThanFive(text: "Razan")


func convertToCelsius(fahrenheit: Double) -> Double {
    let celsius = (fahrenheit - 32) * 5/9
    return celsius
}

convertToCelsius(fahrenheit: 23)
           
                


